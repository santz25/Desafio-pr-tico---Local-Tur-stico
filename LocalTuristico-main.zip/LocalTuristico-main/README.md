# Local Turístico: Conheça Busan

![preview](./.github/preview.png)

> Formação Full-Stack: Iniciando o HTML e CSS (desafio prático)

O projeto é uma simples página de turismo que exibe três destinos imperdíveis em Busan, Coreia do Sul.


[🔗 Clique aqui para acessar](https://fel1324.github.io/LocalTuristico/)


## 🛠️ Tecnologias

- HTML
- CSS
- Git e Github


## 💚 Contato

rafael.roberto200618@gmail.com

---

Feito com ♥ by Rocketseat :wave: [Participe da nossa comunidade!](https://discord.gg/rocketseat)